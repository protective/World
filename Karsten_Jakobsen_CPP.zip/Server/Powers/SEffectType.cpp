/* 
 * File:   SEffectType.cpp
 * Author: karsten
 * 
 * Created on 20. december 2012, 22:15
 */

#include "SEffectType.h"
#include "SPowerType.h"
SEffectType::SEffectType() {
}




SEffectType::~SEffectType() {
}

