/* 
 * File:   SPowerSpellType.cpp
 * Author: karsten
 * 
 * Created on 10. november 2012, 21:04
 */

#include "SPowerSpellType.h"

SPowerSpellType::SPowerSpellType(uint32_t id):
SPowerType(id){
}


SPowerSpellType::~SPowerSpellType() {
}

