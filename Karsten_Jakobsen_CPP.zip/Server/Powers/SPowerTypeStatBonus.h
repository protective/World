/* 
 * File:   SPowerTypeStatBonus.h
 * Author: karsten
 *
 * Created on 22. november 2012, 19:30
 */

#ifndef SPOWERTYPESTATBONUS_H
#define	SPOWERTYPESTATBONUS_H

class SPowerTypeStatBonus {
public:
	SPowerTypeStatBonus();
	SPowerTypeStatBonus(const SPowerTypeStatBonus& orig);
	virtual ~SPowerTypeStatBonus();
private:

};

#endif	/* SPOWERTYPESTATBONUS_H */

