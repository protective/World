/* 
 * File:   SPowerTypeStatBonus.cpp
 * Author: karsten
 * 
 * Created on 22. november 2012, 19:30
 */

#include "SPowerTypeStatBonus.h"

SPowerTypeStatBonus::SPowerTypeStatBonus() {
}

SPowerTypeStatBonus::SPowerTypeStatBonus(const SPowerTypeStatBonus& orig) {
}

SPowerTypeStatBonus::~SPowerTypeStatBonus() {
}

