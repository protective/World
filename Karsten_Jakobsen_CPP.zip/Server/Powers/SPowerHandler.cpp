/* 
 * File:   SPowerHandler.cpp
 * Author: karsten
 * 
 * Created on 1. november 2012, 20:41
 */

#include "SPowerHandler.h"

SPowerHandler::SPowerHandler() {
}

SPowerHandler::~SPowerHandler() {
}

