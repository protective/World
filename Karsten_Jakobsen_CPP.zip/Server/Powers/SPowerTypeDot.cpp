/* 
 * File:   SPowerTypeDot.cpp
 * Author: karsten
 * 
 * Created on 22. november 2012, 19:29
 */

#include "SPowerTypeDot.h"

SPowerTypeDot::SPowerTypeDot() {
}

SPowerTypeDot::~SPowerTypeDot() {
}

