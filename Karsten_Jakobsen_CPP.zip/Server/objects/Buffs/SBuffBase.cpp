/* 
 * File:   SBuffBase.cpp
 * Author: karsten
 * 
 * Created on 22. november 2012, 20:02
 */

#include "SBuffBase.h"

SBuffBase::SBuffBase(SBuff* buff) {
	_buff = buff;
}


SBuffBase::~SBuffBase() {
}

