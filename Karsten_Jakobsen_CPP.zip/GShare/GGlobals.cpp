/* 
 * File:   GGlobals.cpp
 * Author: karsten
 * 
 * Created on 23. april 2011, 11:04
 */

#include "GGlobals.h"

bool printbufferbool = true;
bool printposbufferbool = true;
uint32_t Gtime = 0;
double MySin[360];
double MyCos[360];