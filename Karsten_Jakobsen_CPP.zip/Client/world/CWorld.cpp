/* 
 * File:   CWorld.cpp
 * Author: karsten
 * 
 * Created on 8. februar 2012, 19:44
 */

#include "CWorld.h"

CWorld::CWorld() {
}


CWorld::~CWorld() {
}

