/* 
 * File:   CGrid.cpp
 * Author: karsten
 * 
 * Created on 8. februar 2012, 19:27
 */

#include "CGrid.h"

CGrid::CGrid(uint32_t id, uint32_t spaceWight, uint32_t spaceHight) {
	_id = id;
	_spaceWight = spaceWight;
	_spaceHight = spaceHight;
}

CGrid::~CGrid() {
}

