/* 
 * File:   CDatabase.h
 * Author: karsten
 *
 * Created on 17. september 2011, 19:27
 */

#ifndef CDATABASE_H
#define	CDATABASE_H
#include "CFunctions.h"
class CDatabase {
public:
	CDatabase();

	void updateItemRefs();
	virtual ~CDatabase();
private:

};

#endif	/* CDATABASE_H */

