/* 
 * File:   CDatabase.cpp
 * Author: karsten
 * 
 * Created on 17. september 2011, 19:27
 */

#include "CDatabase.h"

CDatabase::CDatabase() {
}

void CDatabase::updateItemRefs(){

}


CDatabase::~CDatabase() {
}

