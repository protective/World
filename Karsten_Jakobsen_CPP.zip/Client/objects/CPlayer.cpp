/* 
 * File:   CPlayer.cpp
 * Author: karsten
 * 
 * Created on 27. april 2013, 13:33
 */

#include "CPlayer.h"

CPlayer::CPlayer(uint32_t id, uint32_t playerId, CPos pos):
CObj(id,playerId,pos) {
}



CPlayer::~CPlayer() {
}

