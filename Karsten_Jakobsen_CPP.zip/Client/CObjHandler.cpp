/* 
 * File:   CObjHandler.cpp
 * Author: karsten
 * 
 * Created on 1. januar 2013, 19:53
 */

#include "CObjHandler.h"

CObjHandler::CObjHandler() {
}


CObjHandler::~CObjHandler() {
}

